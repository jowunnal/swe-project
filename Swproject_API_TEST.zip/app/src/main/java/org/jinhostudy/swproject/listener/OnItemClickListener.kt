package org.jinhostudy.swproject.listener

import android.view.View

interface OnItemClickListener {
    fun SetOnItemClickListener(v:View,pos:Int)
}