package org.jinhostudy.swproject.data

data class Meal(
    val bld : String,
    val bldMenu : String
)
